import { useState, useEffect } from 'react';

// 关系数据接口
interface Relationship {
  id?: string;
  name: string;
  partnerName: string;
  startDate: string;
  daysTogether: number;
}

// 默认关系数据
const defaultRelationship: Relationship = {
  name: '我们的恋爱',
  partnerName: '亲爱的',
  startDate: '2023-06-01',
  daysTogether: 0
};

// 计算恋爱天数
const calculateDaysTogether = (startDate: string): number => {
  const start = new Date(startDate);
  const today = new Date();
  const diffTime = today.getTime() - start.getTime();
  const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
  return diffDays > 0 ? diffDays : 0;
};

// 自定义Hook: 管理恋爱关系数据
export function useRelationship() {
  // 从localStorage加载数据或使用默认值
  const [relationship, setRelationship] = useState<Relationship>(() => {
    try {
      const saved = localStorage.getItem('relationship');
      if (saved) {
        const parsed = JSON.parse(saved);
        return {
          ...parsed,
          daysTogether: calculateDaysTogether(parsed.startDate)
        };
      }
    } catch (error) {
      console.error('Failed to load relationship data:', error);
    }
    return {
      ...defaultRelationship,
      daysTogether: calculateDaysTogether(defaultRelationship.startDate)
    };
  });

  // 保存关系数据到localStorage
  useEffect(() => {
    try {
      localStorage.setItem('relationship', JSON.stringify(relationship));
    } catch (error) {
      console.error('Failed to save relationship data:', error);
    }
  }, [relationship]);

  // 更新关系信息
  const updateRelationship = (data: Partial<Relationship>) => {
    setRelationship(prev => {
      const updated = { ...prev, ...data };
      // 如果更新了开始日期，重新计算恋爱天数
      if (data.startDate) {
        updated.daysTogether = calculateDaysTogether(data.startDate);
      }
      return updated;
    });
  };

  return {
    relationship,
    updateRelationship
  };
}