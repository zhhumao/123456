import { useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';

// 模拟相册数据
const albums = [
  {
    id: 1,
    name: '日常点滴',
    coverImage: 'https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=couple%20daily%20life%20candid%20photo&sign=6efc8193d85b380a041bc3ff0f06d733',
    photoCount: 42
  },
  {
    id: 2,
    name: '旅行记忆',
    coverImage: 'https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=couple%20travel%20photo%20mountains%20background&sign=c555d48275ad184dc51169f3c5caf7b9',
    photoCount: 28
  },
  {
    id: 3,
    name: '节日庆祝',
    coverImage: 'https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=couple%20celebrating%20birthday%20with%20cake&sign=336cab35aed056beae2a40581f65bfdf',
    photoCount: 15
  },
  {
    id: 4,
    name: '特殊时刻',
    coverImage: 'https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=couple%20kiss%20sunset%20beach%20romantic&sign=75d7bb4597c832c7e2e691639fb6b3ef',
    photoCount: 9
  }
];

// 模拟照片数据
const recentPhotos = [
  {
    id: 1,
    url: 'https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=couple%20hiking%20mountain%20top%20view&sign=b9b072fb34034425035e79cf240d4d1d',
    date: '2025-09-10',
    location: '山顶'
  },
  {
    id: 2,
    url: 'https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=couple%20cooking%20together%20kitchen%20smile&sign=458e49c71bfc77511ccd37faf8429257',
    date: '2025-09-05',
    location: '家里'
  },
  {
    id: 3,
    url: 'https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=couple%20watching%20movie%20theater%20popcorn&sign=a293065b57afa4de3e3a01fe83ff2ef1',
    date: '2025-09-01',
    location: '电影院'
  },
  {
    id: 4,
    url: 'https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=couple%20holding%20hands%20walk%20sunset%20beach&sign=82b418932be031262d3d651a8a293e96',
    date: '2025-08-28',
    location: '海滩'
  },
  {
    id: 5,
    url: 'https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=couple%20coffee%20shop%20smile%20morning&sign=7d5adc60665b4746b9caf8a4f646661f',
    date: '2025-08-25',
    location: '咖啡馆'
  },
  {
    id: 6,
    url: 'https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=couple%20bicycle%20ride%20country%20road&sign=c90eecdf4c0dbdcd295556860c7b3a64',
    date: '2025-08-20',
    location: '乡间小路'
  },
  {
    id: 7,
    url: 'https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=couple%20concert%20live%20music%20happy&sign=02c28837f963af64474b1c7c537e7a9f',
    date: '2025-08-15',
    location: '音乐节'
  },
  {
    id: 8,
    url: 'https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=couple%20picnic%20park%20sunny%20day&sign=86ad0db1429b639db38ae3d573fa0215',
    date: '2025-08-10',
    location: '公园'
  }
];

import { useParams } from 'react-router-dom';

export default function Memories() {
  const { id } = useParams<{ id?: string }>();
  const [selectedPhoto, setSelectedPhoto] = useState<number | null>(id ? parseInt(id) : null);

  return (
    <div className="min-h-screen bg-gradient-to-b from-pink-50 to-white dark:from-gray-900 dark:to-gray-800 transition-colors duration-300">
      {/* 顶部导航 */}
      <header className="sticky top-0 z-40 bg-white/80 dark:bg-gray-900/80 backdrop-blur-md border-b border-pink-100 dark:border-gray-700">
        <div className="container mx-auto px-4 py-3 flex items-center justify-between">
          <Link to="/dashboard" className="text-gray-500 dark:text-gray-400 hover:text-pink-500 dark:hover:text-pink-400">
            <i className="fa-solid fa-arrow-left"></i>
          </Link>
          <h1 className="text-xl font-bold text-gray-800 dark:text-gray-200">记忆库</h1>
          <button className="text-gray-500 dark:text-gray-400 hover:text-pink-500 dark:hover:text-pink-400">
            <i className="fa-solid fa-search"></i>
          </button>
        </div>
      </header>

      <main className="container mx-auto px-4 py-6">
        {/* 添加照片按钮 */}
        <div className="flex justify-end mb-8">
          <button className="bg-gradient-to-r from-pink-500 to-rose-500 hover:from-pink-600 hover:to-rose-600 text-white px-4 py-2 rounded-full shadow-md flex items-center transition-all hover:shadow-lg">
            <i className="fa-solid fa-plus mr-2"></i>
            <span>添加照片</span>
          </button>
        </div>

        {/* 相册分类 */}
        <section className="mb-12">
          <h2 className="text-xl font-bold text-gray-800 dark:text-gray-200 mb-6">相册分类</h2>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {albums.map(album => (
              <div key={album.id} className="group relative overflow-hidden rounded-xl aspect-square shadow-sm border border-pink-100 dark:border-gray-700">
                <img 
                  src={album.coverImage} 
                  alt={album.name}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/30 to-transparent flex flex-col justify-end p-4">
                  <h3 className="text-white font-semibold text-lg">{album.name}</h3>
                  <p className="text-gray-200 text-sm">{album.photoCount} 张照片</p>
                </div>
              </div>
            ))}
            
            {/* 添加相册 */}
            <div className="bg-white dark:bg-gray-800 rounded-xl aspect-square shadow-sm border border-dashed border-pink-200 dark:border-gray-700 flex flex-col items-center justify-center text-pink-500 dark:text-pink-400 hover:border-pink-400 dark:hover:border-pink-500 transition-colors cursor-pointer">
              <i className="fa-solid fa-plus text-3xl mb-2"></i>
              <span className="font-medium">新建相册</span>
            </div>
          </div>
        </section>

        {/* 最近照片 */}
        <section>
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold text-gray-800 dark:text-gray-200">最近照片</h2>
            <button className="text-pink-500 dark:text-pink-400 text-sm font-medium hover:underline">
              查看全部
            </button>
          </div>
          
          {/* 照片网格 */}
          <div className="grid grid-cols-3 gap-2">
            {recentPhotos.map(photo => (
              <motion.div 
                key={photo.id}
                className="relative overflow-hidden rounded-lg aspect-square cursor-pointer group"
                onClick={() => setSelectedPhoto(photo.id)}
                whileHover={{ scale: 1.05 }}
                transition={{ duration: 0.3 }}
              >
                <img 
                  src={photo.url} 
                  alt={`照片 ${photo.id}`}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-black/0 group-hover:bg-black/30 transition-colors duration-300 flex items-center justify-center opacity-0 group-hover:opacity-100">
                  <div className="bg-white/90 dark:bg-gray-900/90 rounded-full p-2">
                    <i className="fa-solid fa-heart text-pink-500"></i>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </section>
      </main>

      {/* 照片查看器模态框 */}
      {selectedPhoto && (
        <div className="fixed inset-0 bg-black/90 z-50 flex items-center justify-center p-4">
          <button 
            onClick={() => setSelectedPhoto(null)}
            className="absolute top-4 right-4 text-white text-2xl"
          >
            <i className="fa-solid fa-times"></i>
          </button>
          
          <div className="max-w-4xl w-full max-h-[80vh]">
            <img 
              src={recentPhotos.find(p => p.id === selectedPhoto)?.url} 
              alt="大图预览"
              className="w-full h-full object-contain"
            />
            
            <div className="bg-white/10 backdrop-blur-md rounded-b-xl p-4 mt-2 text-white">
              <h3 className="text-xl font-bold mb-1">照片详情</h3>
              <p className="text-gray-300 text-sm mb-3">
                {recentPhotos.find(p => p.id === selectedPhoto)?.date} · {recentPhotos.find(p => p.id === selectedPhoto)?.location}
              </p>
              <div className="flex space-x-3">
                <button className="flex-1 bg-white/20 hover:bg-white/30 py-2 rounded-lg transition-colors">
                  <i className="fa-solid fa-heart mr-2"></i> 收藏
                </button>
                <button className="flex-1 bg-white/20 hover:bg-white/30 py-2 rounded-lg transition-colors">
                  <i className="fa-solid fa-share mr-2"></i> 分享
                </button>
                <button className="flex-1 bg-white/20 hover:bg-white/30 py-2 rounded-lg transition-colors">
                  <i className="fa-solid fa-pen mr-2"></i> 编辑
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 底部导航 */}
      <footer className="fixed bottom-0 left-0 right-0 bg-white dark:bg-gray-900 border-t border-pink-100 dark:border-gray-800 z-30">
        <div className="container mx-auto">
          <div className="flex justify-around">
            <Link 
              to="/" 
              className="flex flex-col items-center py-3 px-4 text-gray-500 dark:text-gray-400 hover:text-pink-500 dark:hover:text-pink-400 transition-colors"
            >
              <i className="fa-solid fa-home text-xl mb-1"></i>
              <span className="text-xs font-medium">首页</span>
            </Link>
            <Link 
              to="/timeline" 
              className="flex flex-col items-center py-3 px-4 text-gray-500 dark:text-gray-400 hover:text-pink-500 dark:hover:text-pink-400 transition-colors"
            >
              <i className="fa-solid fa-clock-rotate-left text-xl mb-1"></i>
              <span className="text-xs font-medium">时间线</span>
            </Link>
            <Link 
              to="/add" 
              className="flex flex-col items-center justify-center w-14 h-14 -mt-5 bg-gradient-to-r from-pink-500 to-rose-500 rounded-full shadow-lg text-white border-4 border-white dark:border-gray-900"
            >
              <i className="fa-solid fa-plus text-xl"></i>
            </Link>
            <Link 
              to="/memories" 
              className="flex flex-col items-center py-3 px-4 text-pink-500 dark:text-pink-400"
            >
              <i className="fa-solid fa-camera text-xl mb-1"></i>
              <span className="text-xs font-medium">记忆</span>
            </Link>
            <Link 
              to="/profile" 
              className="flex flex-col items-center py-3 px-4 text-gray-500 dark:text-gray-400 hover:text-pink-500 dark:hover:text-pink-400 transition-colors"
            >
              <i className="fa-solid fa-user text-xl mb-1"></i>
              <span className="text-xs font-medium">我们</span>
            </Link>
          </div>
        </div>
      </footer>
    </div>
  );
}