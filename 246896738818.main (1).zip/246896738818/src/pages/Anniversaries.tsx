import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { useRelationship } from '@/hooks/useRelationship';

// 模拟纪念日数据
const anniversaries = [
  {
    id: 1,
    title: '相识纪念日',
    date: '05-15',
    description: '我们在朋友聚会上第一次相遇的日子',
    type: 'love',
    year: 2023,
    isLunar: false
  },
  {
    id: 2,
    title: '确立关系',
    date: '06-01',
    description: '我们正式成为情侣的日子',
    type: 'relationship',
    year: 2023, 
    isLunar: false
  },
  {
    id: 3,
    title: '第一次约会',
    date: '05-20',
    description: '在那家有小花园的意大利餐厅',
    type: 'date',
    year: 2023,
    isLunar: false
  },
  {
    id: 4,
    title: '生日',
    date:'10-25',
    description: '亲爱的生日',
    type: 'birthday',
    year: 1998,
    isLunar: false
  },
  {
    id: 5,
    title: '我的生日',
    date: '03-18',
    description: '我的生日',
    type: 'birthday',
    year: 1999,
    isLunar: false
  }
];

// 计算距离某个日期的天数
const getDaysUntil = (month: number, day: number): number => {
  const today = new Date();
  const nextDate = new Date(today.getFullYear(), month - 1, day);
  
  if (nextDate < today) {
    nextDate.setFullYear(today.getFullYear() + 1);
  }
  
  const diffTime = nextDate.getTime() - today.getTime();
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  
  return diffDays;
};

// 计算周年数
const getYears = (year: number): number => {
  return new Date().getFullYear() - year;
};

// 纪念日类型图标
const AnniversaryIcon = ({ type }: { type: string }) => {
  const icons = {
    love: <i className="fa-solid fa-heart text-pink-500"></i>,
    relationship: <i className="fa-solid fa-ring text-purple-500"></i>,
    date: <i className="fa-solid fa-calendar-day text-blue-500"></i>,
    birthday: <i className="fa-solid fa-cake-candles text-yellow-500"></i>,holiday: <i className="fa-solid fa-gift text-green-500"></i>
  };
  
  return <span className="text-xl">{icons[type as keyof typeof icons] || <i className="fa-solid fa-star text-gray-500"></i>}</span>;
};

export default function Anniversaries() {
  const { relationship } = useRelationship();
  const [sortedAnniversaries, setSortedAnniversaries] = useState(anniversaries);
  const [currentDate] = useState(new Date());
  
  // 按日期排序纪念日
  useEffect(() => {
    const sorted = [...anniversaries].sort((a, b) => {
      const aMonth = parseInt(a.date.split('-')[0]);
      const aDay = parseInt(a.date.split('-')[1]);
      const bMonth = parseInt(b.date.split('-')[0]);
      const bDay = parseInt(b.date.split('-')[1]);
      
      const aDays = getDaysUntil(aMonth, aDay);
      const bDays = getDaysUntil(bMonth, bDay);
      
      return aDays - bDays;
    });
    
    setSortedAnniversaries(sorted);
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-b from-pink-50 to-white dark:from-gray-900 dark:to-gray-800 transition-colors duration-300">
      {/* 顶部导航 */}
      <header className="sticky top-0 z-30 bg-white/80 dark:bg-gray-900/80 backdrop-blur-md border-b border-pink-100 dark:border-gray-700">
        <div className="container mx-auto px-4 py-3 flex items-center justify-between">
          <Link to="/dashboard" className="text-gray-500 dark:text-gray-400 hover:text-pink-500 dark:hover:text-pink-400">
            <i className="fa-solid fa-arrow-left"></i>
          </Link>
          <h1 className="text-xl font-bold text-gray-800 dark:text-gray-200">重要日期</h1>
          <div className="w-6"></div> {/* 占位元素，保持标题居中 */}
        </div>
      </header>

      <main className="container mx-auto px-4 py-6">
        {/* 当前日期 */}
        <div className="text-center mb-8">
          <h2 className="text-2xl font-bold text-gray-800 dark:text-gray-200">
            {currentDate.getFullYear()}年{currentDate.getMonth() + 1}月{currentDate.getDate()}日
          </h2>
          <p className="text-gray-600 dark:text-gray-400 mt-1">今日</p>
        </div>

        {/* 添加纪念日按钮 */}
        <div className="flex justify-end mb-8">
          <button className="bg-gradient-to-r from-pink-500 to-rose-500 hover:from-pink-600 hover:to-rose-600 text-white px-4 py-2 rounded-full shadow-md flex items-center transition-all hover:shadow-lg">
            <i className="fa-solid fa-plus mr-2"></i>
            <span>添加纪念日</span>
          </button>
        </div>

        {/* 纪念日列表 */}
        <div className="space-y-6">
          {sortedAnniversaries.map((anniversary) => {
            const [month, day] = anniversary.date.split('-').map(Number);
            const daysUntil = getDaysUntil(month, day);
            const years = getYears(anniversary.year);
            
            return (
              <motion.div 
                key={anniversary.id}
                className="bg-white dark:bg-gray-800 rounded-xl p-5 shadow-sm border border-pink-100 dark:border-gray-700 hover:shadow-md transition-all"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: anniversary.id * 0.05 }}
              >
                <div className="flex justify-between items-start">
                  <div className="flex items-center">
                    <div className="mr-4 p-3 bg-pink-100 dark:bg-pink-900/30 rounded-full">
                      <AnniversaryIcon type={anniversary.type} />
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-gray-800 dark:text-gray-200">{anniversary.title}</h3>
                      <p className="text-gray-500 dark:text-gray-400 text-sm mt-1">{anniversary.date} {anniversary.isLunar ? '(农历)' : ''}</p>
                    </div>
                  </div>
                  
                  <div className="text-right">
                    <div className={`text-2xl font-bold ${daysUntil === 0 ? 'text-pink-500' : 'bg-gradient-to-r from-pink-500 to-rose-500 bg-clip-text text-transparent'}`}>
                      {daysUntil === 0 ? '今天' : `${daysUntil} 天`}
                    </div>
                    <p className="text-gray-500 dark:text-gray-400 text-sm mt-1">
                      {years > 0 ? `${years} 年` : ''}
                    </p>
                  </div>
                </div>
                
                <p className="text-gray-600 dark:text-gray-300 mt-4">{anniversary.description}</p>
                
                {years > 0 && (
                  <div className="mt-4 pt-4 border-t border-gray-100 dark:border-gray-700">
                    <div className="text-sm text-gray-500 dark:text-gray-400">
                      <span className="font-medium">已陪伴 {years} 年</span> · {years * 365 + daysUntil} 天
                    </div>
                  </div>
                )}
                
                {daysUntil === 0 && (
                  <div className="mt-4 pt-4 border-t border-gray-100 dark:border-gray-700 bg-pink-50 dark:bg-pink-900/10 rounded-lg p-3">
                    <div className="flex items-center text-pink-600 dark:text-pink-400">
                      <i className="fa-solid fa-birthday-cake mr-2"></i>
                      <span className="font-medium">今天是这个特别的日子！</span>
                    </div>
                    <div className="mt-2 flex space-x-2">
                      <button className="text-xs bg-pink-100 dark:bg-pink-900/30 text-pink-600 dark:text-pink-400 px-3 py-1 rounded-full hover:bg-pink-200 dark:hover:bg-pink-900/50 transition-colors">
                        查看礼物建议
                      </button>
                      <button className="text-xs bg-pink-100 dark:bg-pink-900/30 text-pink-600 dark:text-pink-400 px-3 py-1 rounded-full hover:bg-pink-200 dark:hover:bg-pink-900/50 transition-colors">
                        设置提醒
                      </button>
                    </div>
                  </div>
                )}
              </motion.div>
            );
          })}
        </div>
      </main>

      {/* 底部导航 */}
      <footer className="fixed bottom-0 left-0 right-0 bg-white dark:bg-gray-900 border-t border-pink-100 dark:border-gray-800 z-30">
        <div className="container mx-auto">
          <div className="flex justify-around">
            <Link 
              to="/" 
              className="flex flex-col items-center py-3 px-4 text-gray-500 dark:text-gray-400 hover:text-pink-500 dark:hover:text-pink-400 transition-colors"
            >
              <i className="fa-solid fa-home text-xl mb-1"></i>
              <span className="text-xs font-medium">首页</span>
            </Link>
            <Link 
              to="/timeline" 
              className="flex flex-col items-center py-3 px-4 text-gray-500 dark:text-gray-400 hover:text-pink-500 dark:hover:text-pink-400 transition-colors"
            >
              <i className="fa-solid fa-clock-rotate-left text-xl mb-1"></i>
              <span className="text-xs font-medium">时间线</span>
            </Link>
            <Link 
              to="/add" 
              className="flex flex-col items-center justify-center w-14 h-14 -mt-5 bg-gradient-to-r from-pink-500 to-rose-500 rounded-full shadow-lg text-white border-4 border-white dark:border-gray-900"
            >
              <i className="fa-solid fa-plus text-xl"></i>
            </Link>
            <Link 
              to="/memories" 
              className="flex flex-col items-center py-3 px-4 text-gray-500 dark:text-gray-400 hover:text-pink-500 dark:hover:text-pink-400 transition-colors"
            >
              <i className="fa-solid fa-camera text-xl mb-1"></i>
              <span className="text-xs font-medium">记忆</span>
            </Link>
            <Link 
              to="/profile" 
              className="flex flex-col items-center py-3 px-4 text-gray-500 dark:text-gray-400 hover:text-pink-500 dark:hover:text-pink-400 transition-colors"
            >
              <i className="fa-solid fa-user text-xl mb-1"></i>
              <span className="text-xs font-medium">我们</span>
            </Link>
          </div>
        </div>
      </footer>
    </div>
  );
}