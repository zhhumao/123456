import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';

// 添加选项类型
type AddOption = 'memory' | 'journal' | 'event' | 'anniversary';

// 添加选项接口
interface AddOptionItem {
  id: AddOption;
  icon: React.ReactNode;
  title: string;
  description: string;
  color: string;
  path: string;
}

export default function AddPage() {
  const navigate = useNavigate();
  const [selectedOption, setSelectedOption] = useState<AddOption | null>(null);
  
  // 添加选项数据
  const addOptions: AddOptionItem[] = [
    {
      id: 'memory',
      icon: <i className="fa-solid fa-camera text-white text-2xl"></i>,
      title: '添加照片',
      description: '记录美好瞬间',
      color: 'from-pink-500 to-rose-500',
      path: '/add/memory'
    },
    {
      id: 'journal',
      icon: <i className="fa-solid fa-book text-white text-2xl"></i>,
      title: '写日记',
      description: '记录今日心情',
      color: 'from-blue-500 to-cyan-500',
      path: '/add/journal'
    },
    {
      id: 'event',
      icon: <i className="fa-solid fa-calendar-plus text-white text-2xl"></i>,
      title: '添加事件',
      description: '记录重要时刻',
      color: 'from-purple-500 to-indigo-500',
      path: '/add/event'
    },
    {
      id: 'anniversary',
      icon: <i className="fa-solid fa-gift text-white text-2xl"></i>,
      title: '添加纪念日',
      description: '设置特别日期',
      color: 'from-amber-500 to-orange-500',
      path: '/add/anniversary'
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-pink-50 to-white dark:from-gray-900 dark:to-gray-800 transition-colors duration-300">
      {/* 顶部导航 */}
      <header className="sticky top-0 z-30 bg-white/80 dark:bg-gray-900/80 backdrop-blur-md border-b border-pink-100 dark:border-gray-700">
        <div className="container mx-auto px-4 py-3 flex items-center justify-between">
          <Link to="/dashboard" className="text-gray-500 dark:text-gray-400 hover:text-pink-500 dark:hover:text-pink-400">
            <i className="fa-solid fa-arrow-left"></i>
          </Link>  
          <h1 className="text-xl font-bold text-gray-800 dark:text-gray-200">添加内容</h1>
          <div className="w-6"></div> {/* 占位元素，保持标题居中 */}
        </div>
      </header>

      <main className="container mx-auto px-4 py-12">
        <div className="text-center mb-12">
          <h2 className="text-2xl font-bold text-gray-800 dark:text-gray-200 mb-2">你想添加什么？</h2>
          <p className="text-gray-600 dark:text-gray-400">选择一个选项开始记录美好回忆</p>
        </div>

        {/* 添加选项网格 */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-2xl mx-auto">
          {addOptions.map(option => (
            <motion.div 
              key={option.id}
              className={`group relative rounded-2xl overflow-hidden shadow-lg cursor-pointer h-48 transform transition-all duration-300 hover:scale-105 ${selectedOption === option.id ? 'scale-105 shadow-xl' : ''}`}
              onClick={() => navigate(option.path)}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: addOptions.indexOf(option) * 0.1 }}
            >
              {/* 渐变背景 */}
              <div className={`absolute inset-0 bg-gradient-to-br ${option.color} opacity-90 group-hover:opacity-100 transition-opacity`}></div>
              
              {/* 图标 */}
              <div className="absolute top-6 left-6">
                {option.icon}
              </div>
              
              {/* 文字内容 */}
              <div className="absolute bottom-6 left-6 right-6">
                <h3 className="text-xl font-bold text-white mb-1">{option.title}</h3>
                <p className="text-white/80 text-sm">{option.description}</p>
              </div>
              
              {/* 箭头图标 */}
              <div className="absolute bottom-6 right-6 text-white/70 group-hover:text-white transition-colors">
                <i className="fa-solid fa-arrow-right"></i>
              </div>
            </motion.div>
          ))}
        </div>
      </main>

      {/* 底部导航 */}
      <footer className="fixed bottom-0 left-0 right-0 bg-white dark:bg-gray-900 border-t border-pink-100 dark:border-gray-800 z-30">
        <div className="container mx-auto">
          <div className="flex justify-around">
            <Link 
              to="/" 
              className="flex flex-col items-center py-3 px-4 text-gray-500 dark:text-gray-400 hover:text-pink-500 dark:hover:text-pink-400 transition-colors"
            >
              <i className="fa-solid fa-home text-xl mb-1"></i>
              <span className="text-xs font-medium">首页</span>
            </Link>
            <Link 
              to="/timeline" 
              className="flex flex-col items-center py-3 px-4 text-gray-500 dark:text-gray-400 hover:text-pink-500 dark:hover:text-pink-400 transition-colors"
            >
              <i className="fa-solid fa-clock-rotate-left text-xl mb-1"></i>
              <span className="text-xs font-medium">时间线</span>
            </Link>
            <Link 
              to="/add" 
              className="flex flex-col items-center justify-center w-14 h-14 -mt-5 bg-gradient-to-r from-pink-500 to-rose-500 rounded-full shadow-lg text-white border-4 border-white dark:border-gray-900"
            >
              <i className="fa-solid fa-plus text-xl"></i>
            </Link>
            <Link 
              to="/memories" 
              className="flex flex-col items-center py-3 px-4 text-gray-500 dark:text-gray-400 hover:text-pink-500 dark:hover:text-pink-400 transition-colors"
            >
              <i className="fa-solid fa-camera text-xl mb-1"></i>
              <span className="text-xs font-medium">记忆</span>
            </Link>
            <Link 
              to="/profile" 
              className="flex flex-col items-center py-3 px-4 text-gray-500 dark:text-gray-400 hover:text-pink-500 dark:hover:text-pink-400 transition-colors"
            >
              <i className="fa-solid fa-user text-xl mb-1"></i>
              <span className="text-xs font-medium">我们</span>
            </Link>
          </div>
        </div>
      </footer>
    </div>
  );
}