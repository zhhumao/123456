import { useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';

// 模拟日记数据
const journalEntries = [
  {
    id: 1,
    title: '我们的未来计划',
    date: '2025-09-10',
    excerpt: '今天我们聊了很多关于未来的打算，感觉我们对未来的憧憬越来越一致了。他说想明年一起去日本旅行，我也一直想去那里看看樱花。我们还讨论了要不要养一只猫，我喜欢橘猫，他喜欢黑猫，也许我们可以养两只？',
    mood: 'happy',
    weather: 'sunny'
  },
  {
    id: 2,
    title: '小小的惊喜',
    date: '2025-09-05',
    excerpt: '他今天给了我一个惊喜，带我去了我们第一次约会的餐厅，太感动了。他还记得我当时点的每一道菜，甚至记得我不小心打翻水杯的糗事。饭后我们在河边散步，就像第一次约会时一样。这样的小惊喜，让我觉得特别幸福。',
    mood: 'loving',
    weather: 'cloudy'
  },
  {
    id: 3,
    title: '第一次争吵',
    date: '2025-08-28',
    excerpt: '我们今天因为一件小事吵架了，这是我们在一起以来第一次真正意义上的争吵。冷静下来后，我们好好谈了谈，发现其实只是沟通方式的问题。通过这次争吵，我感觉我们更了解彼此了。重要的不是不吵架，而是吵架后的和解方式。',
    mood: 'sad',
    weather: 'rainy'
  },
  {
    id: 4,
    title: '平凡的幸福',
    date: '2025-08-20',
    excerpt: '今天没有什么特别的事情，就是一起去超市买菜，然后回家做饭。他切菜我洗碗，简单的日常却让我感到很安心。也许幸福就是这样，不需要轰轰烈烈，而是这些平凡生活中的点点滴滴积累起来的。',
    mood: 'peaceful',
    weather: 'sunny'
  },
  {
    id: 5,
    title: '他的生日',
    date: '2025-08-15',
    excerpt: '今天是他的生日，我偷偷准备了一个惊喜派对，邀请了我们的好朋友。看到他感动的样子，我也觉得特别开心。他说这是他过得最难忘的一个生日，听到这句话，我觉得所有的准备都值得了。',
    mood: 'excited',
    weather: 'sunny'
  }
];

// 情绪图标组件
const MoodIcon = ({ mood }: { mood: string }) => {
  const icons = {
    happy: <i className="fa-solid fa-face-laugh-beam text-yellow-400"></i>,
    loving: <i className="fa-solid fa-heart text-pink-500"></i>,
    sad: <i className="fa-solid fa-face-sad-tear text-blue-400"></i>,
    peaceful: <i className="fa-solid fa-face-smile text-green-400"></i>,
    excited: <i className="fa-solid fa-face-grin-stars text-purple-400"></i>
  };
  
  return <span className="text-xl">{icons[mood as keyof typeof icons] || <i className="fa-solid fa-face-meh text-gray-400"></i>}</span>;
};

// 天气图标组件
const WeatherIcon = ({ weather }: { weather: string }) => {
  const icons = {
    sunny: <i className="fa-solid fa-sun text-yellow-500"></i>,
    cloudy: <i className="fa-solid fa-cloud text-gray-400"></i>,
    rainy: <i className="fa-solid fa-cloud-rain text-blue-400"></i>,
    snowy: <i className="fa-solid fa-snowflake text-blue-200"></i>,
    windy: <i className="fa-solid fa-wind text-gray-300"></i>
  };
  
  return <span>{icons[weather as keyof typeof icons] || <i className="fa-solid fa-circle text-gray-400"></i>}</span>;
};

export default function Journal() {
  const [selectedEntry, setSelectedEntry] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-gradient-to-b from-pink-50 to-white dark:from-gray-900 dark:to-gray-800 transition-colors duration-300">
      {/* 顶部导航 */}
      <header className="sticky top-0 z-30 bg-white/80 dark:bg-gray-900/80 backdrop-blur-md border-b border-pink-100 dark:border-gray-700">
        <div className="container mx-auto px-4 py-3 flex items-center justify-between">
          <Link to="/dashboard" className="text-gray-500 dark:text-gray-400 hover:text-pink-500 dark:hover:text-pink-400">
            <i className="fa-solid fa-arrow-left"></i>
          </Link>
          <h1 className="text-xl font-bold text-gray-800 dark:text-gray-200">恋爱日记</h1>
          <div className="w-6"></div> {/* 占位元素，保持标题居中 */}
        </div>
      </header>

      <main className="container mx-auto px-4 py-6">
        {/* 添加日记按钮 */}
        <div className="flex justify-end mb-8">
          <button className="bg-gradient-to-r from-pink-500 to-rose-500 hover:from-pink-600 hover:to-rose-600 text-white px-4 py-2 rounded-full shadow-md flex items-center transition-all hover:shadow-lg">
            <i className="fa-solid fa-plus mr-2"></i>
            <span>写日记</span>
          </button>
        </div>

        {/* 日记列表 */}
        <div className="space-y-6">
          {journalEntries.map((entry) => (
            <motion.div 
              key={entry.id}
              className={`bg-white dark:bg-gray-800 rounded-xl overflow-hidden shadow-sm border border-pink-100 dark:border-gray-700 transition-all cursor-pointer ${selectedEntry === entry.id ? 'shadow-lg' : 'hover:shadow-md'}`}
              onClick={() => setSelectedEntry(selectedEntry === entry.id ? null : entry.id)}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: entry.id * 0.05 }}
            >
              <div className="p-5">
                <div className="flex justify-between items-start mb-3">
                  <div>
                    <span className="text-xs font-medium text-pink-500 dark:text-pink-400">{entry.date}</span>
                    <h3 className="text-xl font-bold text-gray-800 dark:text-gray-200 mt-1">{entry.title}</h3>
                  </div>
                  <div className="flex items-center space-x-3">
                    <MoodIcon mood={entry.mood} />
                    <WeatherIcon weather={entry.weather} />
                  </div>
                </div>
                
                <p className={`text-gray-600 dark:text-gray-300 transition-all duration-300 ${selectedEntry === entry.id ? 'max-h-96 opacity-100' : 'max-h-12 opacity-70 line-clamp-2'}`}>
                  {entry.excerpt}
                </p>
                
                {selectedEntry === entry.id && (
                  <div className="mt-4 pt-4 border-t border-gray-100 dark:border-gray-700">
                    <div className="flex justify-between text-sm text-gray-500 dark:text-gray-400">
                      <span>
                        <MoodIcon mood={entry.mood} />
                        <span className="ml-1 capitalize">{entry.mood}</span>
                      </span>
                      <span>
                        <WeatherIcon weather={entry.weather} />
                        <span className="ml-1 capitalize">{entry.weather}</span>
                      </span>
                    </div>
                    
                    <div className="flex justify-end mt-4 space-x-3">
                      <button className="text-gray-500 dark:text-gray-400 hover:text-pink-500 dark:hover:text-pink-400 p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors">
                        <i className="fa-solid fa-pen"></i>
                      </button>
                      <button className="text-gray-500 dark:text-gray-400 hover:text-pink-500 dark:hover:text-pink-400 p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors">
                        <i className="fa-solid fa-trash"></i>
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </motion.div>
          ))}
        </div>
      </main>

      {/* 底部导航 */}
      <footer className="fixed bottom-0 left-0 right-0 bg-white dark:bg-gray-900 border-t border-pink-100 dark:border-gray-800 z-30">
        <div className="container mx-auto">
          <div className="flex justify-around">
            <Link 
              to="/" 
              className="flex flex-col items-center py-3 px-4 text-gray-500 dark:text-gray-400 hover:text-pink-500 dark:hover:text-pink-400 transition-colors"
            >
              <i className="fa-solid fa-home text-xl mb-1"></i>
              <span className="text-xs font-medium">首页</span>
            </Link>
            <Link 
              to="/timeline" 
              className="flex flex-col items-center py-3 px-4 text-gray-500 dark:text-gray-400 hover:text-pink-500 dark:hover:text-pink-400 transition-colors"
            >
              <i className="fa-solid fa-clock-rotate-left text-xl mb-1"></i>
              <span className="text-xs font-medium">时间线</span>
            </Link>
            <Link 
              to="/add" 
              className="flex flex-col items-center justify-center w-14 h-14 -mt-5 bg-gradient-to-r from-pink-500 to-rose-500 rounded-full shadow-lg text-white border-4 border-white dark:border-gray-900"
            >
              <i className="fa-solid fa-plus text-xl"></i>
            </Link>
            <Link 
              to="/memories" 
              className="flex flex-col items-center py-3 px-4 text-gray-500 dark:text-gray-400 hover:text-pink-500 dark:hover:text-pink-400 transition-colors"
            >
              <i className="fa-solid fa-camera text-xl mb-1"></i>
              <span className="text-xs font-medium">记忆</span>
            </Link>
            <Link 
              to="/profile" 
              className="flex flex-col items-center py-3 px-4 text-gray-500 dark:text-gray-400 hover:text-pink-500 dark:hover:text-pink-400 transition-colors"
            >
              <i className="fa-solid fa-user text-xl mb-1"></i>
              <span className="text-xs font-medium">我们</span>
            </Link>
          </div>
        </div>
      </footer>
    </div>
  );
}