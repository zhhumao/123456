import { useState } from 'react';
import { Link } from 'react-router-dom';
import { useTheme } from '@/hooks/useTheme';
import { useRelationship } from '@/hooks/useRelationship';
import { useContext } from 'react';
import { AuthContext } from '@/contexts/authContext';

// 设置选项接口
interface SettingOption {
  id: string;
  icon: React.ReactNode;
  title: string;
  description: string;
  path?: string;
  action?: () => void;
}

export default function Profile() {
  const { theme, toggleTheme } = useTheme();
  const { relationship, setRelationship } = useRelationship();
  const { logout } = useContext(AuthContext);
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    name: relationship?.name || '我们的恋爱',
    partnerName: relationship?.partnerName || '亲爱的',
    startDate: relationship?.startDate || '2023-06-01'
  });

  // 处理表单变化
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  // 保存关系信息
  const saveRelationshipInfo = () => {
    if (relationship) {
      setRelationship({
        ...relationship,
        name: formData.name,
        partnerName: formData.partnerName,
        startDate: formData.startDate,
        // 重新计算恋爱天数
        daysTogether: Math.floor((new Date().getTime() - new Date(formData.startDate).getTime()) / (1000 * 60 * 60 * 24))
      });
    }
    setIsEditing(false);
  };

  // 设置选项
  const settingOptions: SettingOption[] = [
    {
      id: 'theme',
      icon: theme === 'light' ? <i className="fa-solid fa-moon text-gray-500"></i> : <i className="fa-solid fa-sun text-yellow-400"></i>,
      title: '主题设置',
      description: theme === 'light' ? '切换到深色模式' : '切换到浅色模式',
      action: toggleTheme
    },
    {
      id: 'privacy',
      icon: <i className="fa-solid fa-lock text-gray-500"></i>,
      title: '隐私设置',
      description: '管理你的隐私和数据',
      path: '/settings/privacy'
    },
    {
      id: 'notifications',
      icon: <i className="fa-solid fa-bell text-gray-500"></i>,
      title: '通知设置',
      description: '管理提醒和通知',
      path: '/settings/notifications'
    },
    {
      id: 'about',
      icon: <i className="fa-solid fa-info-circle text-gray-500"></i>,
      title: '关于我们',
      description: '应用信息和帮助',
      path: '/settings/about'
    },
    {
      id: 'logout',
      icon: <i className="fa-solid fa-sign-out text-red-500"></i>,
      title: '退出登录',
      description: '安全退出当前账号',
      action: logout
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-pink-50 to-white dark:from-gray-900 dark:to-gray-800 transition-colors duration-300">
      {/* 顶部导航 */}
      <header className="sticky top-0 z-30 bg-white/80 dark:bg-gray-900/80 backdrop-blur-md border-b border-pink-100 dark:border-gray-700">
        <div className="container mx-auto px-4 py-3 flex items-center justify-between">
          <Link to="/dashboard" className="text-gray-500 dark:text-gray-400 hover:text-pink-500 dark:hover:text-pink-400">
            <i className="fa-solid fa-arrow-left"></i>
          </Link>
          <h1 className="text-xl font-bold text-gray-800 dark:text-gray-200">我们</h1>
          <div className="w-6"></div> {/* 占位元素，保持标题居中 */}
        </div>
      </header>

      <main className="container mx-auto px-4 py-6">
        {/* 情侣信息卡片 */}
        <section className="mb-12">
          <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-lg overflow-hidden border border-pink-100 dark:border-gray-700">
            <div className="h-32 bg-gradient-to-r from-pink-400 to-rose-500 relative">
              {/* 背景图 */}
              <div className="absolute inset-0 opacity-20">
                <img 
                  src="https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=hearts%20pattern%20pink%20background&sign=face2ceca2bb3afdb71d52b7c1046700" 
                  alt="背景"
                  className="w-full h-full object-cover"
                />
              </div>
              
              {/* 情侣头像 */}
              <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 flex -mb-12">
                <div className="w-20 h-20 rounded-full border-4 border-white dark:border-gray-800 bg-gray-200 overflow-hidden">
                  <img 
                    src="https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=girl%20avatar%20cartoon%20style&sign=f74074d3f8618e57690d3da0d6e46aaa" 
                    alt="我的头像"
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="w-20 h-20 rounded-full border-4 border-white dark:border-gray-800 bg-gray-200 overflow-hidden -ml-6">
                  <img 
                    src="https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=boy%20avatar%20cartoon%20style&sign=76277ecfd65543b6b02c3b1335c87806" 
                    alt="伴侣头像"
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>
            </div>
            
            <div className="pt-16 pb-6 px-6 text-center">
              {isEditing ? (
                <div className="space-y-4">
                  <div>
                    <input
                      type="text"
                      name="name"
                      value={formData.name}
                      onChange={handleInputChange}
                      className="w-full bg-gray-100 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg px-4 py-2 text-center text-gray-800 dark:text-gray-200"
                    />
                  </div>
                  <div className="flex justify-center space-x-4">
                    <div className="w-1/3">
                      <input
                        type="text"
                        name="partnerName"
                        value={formData.partnerName}
                        onChange={handleInputChange}
                        className="w-full bg-gray-100 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg px-4 py-2 text-center text-gray-800 dark:text-gray-200"
                      />
                    </div>
                    <div className="text-xl font-bold text-gray-400 flex items-center">
                      <i className="fa-solid fa-heart text-pink-500 mx-2"></i>
                    </div>
                    <div className="w-1/3">
                      <input
                        type="text"
                        value="我"
                        className="w-full bg-gray-100 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg px-4 py-2 text-center text-gray-800 dark:text-gray-200"
                        disabled
                      />
                    </div>
                  </div>
                  <div>
                    <input
                      type="date"
                      name="startDate"
                      value={formData.startDate}
                      onChange={handleInputChange}
                      className="w-full bg-gray-100 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg px-4 py-2 text-center text-gray-800 dark:text-gray-200"
                    />
                  </div>
                  <div className="flex justify-center space-x-4 mt-6">
                    <button 
                      onClick={() => setIsEditing(false)}
                      className="px-4 py-2 bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-gray-200 rounded-lg hover:bg-gray-300 dark:hover:bg-gray-600 transition-colors"
                    >
                      取消
                    </button>
                    <button 
                      onClick={saveRelationshipInfo}
                      className="px-4 py-2 bg-pink-500 text-white rounded-lg hover:bg-pink-600 transition-colors"
                    >
                      保存
                    </button>
                  </div>
                </div>
              ) : (
                <>
                  <h2 className="text-2xl font-bold text-gray-800 dark:text-gray-200 mb-2">
                    {relationship?.name || '我们的恋爱'}
                  </h2>
                  
                  <div className="flex justify-center items-center space-x-4 mb-4">
                    <span className="text-lg text-gray-800 dark:text-gray-200">{relationship?.partnerName || '亲爱的'}</span>
                    <i className="fa-solid fa-heart text-pink-500"></i>
                    <span className="text-lg text-gray-800 dark:text-gray-200">我</span>
                  </div>
                  
                  <p className="text-gray-500 dark:text-gray-400 mb-6">
                    从 {relationship?.startDate || '2023-06-01'} 开始
                  </p>
                  
                  <div className="flex justify-center space-x-4">
                    <div className="text-center">
                      <p className="text-3xl font-bold bg-gradient-to-r from-pink-500 to-rose-500 bg-clip-text text-transparent">
                        {relationship?.daysTogether || 486}
                      </p>
                      <p className="text-gray-500 dark:text-gray-400 text-sm">恋爱天数</p>
                    </div>
                    <div className="text-center">
                      <p className="text-3xl font-bold bg-gradient-to-r from-pink-500 to-rose-500 bg-clip-text text-transparent">
                        {Math.floor((relationship?.daysTogether || 486) / 30)}
                      </p>
                      <p className="text-gray-500 dark:text-gray-400 text-sm">恋爱月数</p>
                    </div>
                    <div className="text-center">
                      <p className="text-3xl font-bold bg-gradient-to-r from-pink-500 to-rose-500 bg-clip-text text-transparent">
                        {Math.floor((relationship?.daysTogether || 486) / 365)}
                      </p>
                      <p className="text-gray-500 dark:text-gray-400 text-sm">恋爱年数</p>
                    </div>
                  </div>
                  
                  <button 
                    onClick={() => setIsEditing(true)}
                    className="mt-6 text-pink-500 dark:text-pink-400 text-sm font-medium hover:underline"
                  >
                    <i className="fa-solid fa-pen mr-1"></i> 编辑信息
                  </button>
                </>
              )}
            </div>
          </div>
        </section>

        {/* 设置选项 */}
        <section>
          <h2 className="text-xl font-bold text-gray-800 dark:text-gray-200 mb-6">设置</h2>
          
          <div className="space-y-4">
            {settingOptions.map(option => (
              <Link 
                key={option.id}
                to={option.path || '#'}
                className="block bg-white dark:bg-gray-800 rounded-xl p-5 shadow-sm border border-pink-100 dark:border-gray-700 hover:shadow-md transition-all"
                onClick={(e) => {
                  if (option.action) {
                    e.preventDefault();
                    option.action();
                  }
                }}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <div className="w-10 h-10 rounded-full bg-gray-100 dark:bg-gray-700 flex items-center justify-center mr-4">
                      {option.icon}
                    </div>
                    <div>
                      <h3 className="font-semibold text-gray-800 dark:text-gray-200">{option.title}</h3>
                      <p className="text-gray-500 dark:text-gray-400 text-sm">{option.description}</p>
                    </div>
                  </div>
                  {!option.action && (
                    <i className="fa-solid fa-chevron-right text-gray-400"></i>
                  )}
                </div>
              </Link>
            ))}
          </div>
        </section>
      </main>

      {/* 底部导航 */}
      <footer className="fixed bottom-0 left-0 right-0 bg-white dark:bg-gray-900 border-t border-pink-100 dark:border-gray-800 z-30">
        <div className="container mx-auto">
          <div className="flex justify-around">
            <Link 
              to="/" 
              className="flex flex-col items-center py-3 px-4 text-gray-500 dark:text-gray-400 hover:text-pink-500 dark:hover:text-pink-400 transition-colors"
            >
              <i className="fa-solid fa-home text-xl mb-1"></i>
              <span className="text-xs font-medium">首页</span>
            </Link>
            <Link 
              to="/timeline" 
              className="flex flex-col items-center py-3 px-4 text-gray-500 dark:text-gray-400 hover:text-pink-500 dark:hover:text-pink-400 transition-colors"
            >
              <i className="fa-solid fa-clock-rotate-left text-xl mb-1"></i>
              <span className="text-xs font-medium">时间线</span>
            </Link>
            <Link 
              to="/add" 
              className="flex flex-col items-center justify-center w-14 h-14 -mt-5 bg-gradient-to-r from-pink-500 to-rose-500 rounded-full shadow-lg text-white border-4 border-white dark:border-gray-900"
            >
              <i className="fa-solid fa-plus text-xl"></i>
            </Link>
            <Link 
              to="/memories" 
              className="flex flex-col items-center py-3 px-4 text-gray-500 dark:text-gray-400 hover:text-pink-500 dark:hover:text-pink-400 transition-colors"
            >
              <i className="fa-solid fa-camera text-xl mb-1"></i>
              <span className="text-xs font-medium">记忆</span>
            </Link>
            <Link 
              to="/profile" 
              className="flex flex-col items-center py-3 px-4 text-pink-500 dark:text-pink-400"
            >
              <i className="fa-solid fa-user text-xl mb-1"></i>
              <span className="text-xs font-medium">我们</span>
            </Link>
          </div>
        </div>
      </footer>
    </div>
  );
}