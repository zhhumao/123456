import { useState } from 'react';
import { Link } from 'react-router-dom';
import { useRelationship } from '@/hooks/useRelationship';

// 模拟时间线事件数据
const timelineEvents = [
  {
    id: 1,
    date: '2023-05-15',
    title: '我们相识了',
    description: '在朋友的聚会上第一次见面，聊了整整一个晚上。',
    imageUrl: 'https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=first%20meeting%20at%20party%20night%20romantic%20lighting&sign=11c07488caebfc1c9d81d391c0831ea3'
  },
  {
    id: 2,
    date: '2023-05-20',
    title: '第一次约会',
    description: '在那家有小花园的意大利餐厅，你穿了一条蓝色的裙子，很美。',
    imageUrl: 'https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=first%20date%20at%20italian%20restaurant%20garden&sign=bf9b97f23a2688d2b83d6c1925be7d52'
  },
  {
    id: 3,
    date: '2023-06-01',
    title: '正式在一起',
    description: '在海边看日落时，你牵起了我的手，那一刻我知道我们会在一起。',
    imageUrl: 'https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=couple%20holding%20hands%20watching%20sunset%20at%20beach&sign=60f90416a991c131a152b11b5b559b53'
  },
  {
    id: 4,
    date: '2023-08-10',
    title: '第一次旅行',
    description: '一起去了厦门，在鼓浪屿迷失方向，却发现了最美的风景。',
    imageUrl: 'https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=couple%20traveling%20in%20old%20town%20street&sign=0fe49a5b16b3a3fb3470e4a41ef4a5ea'
  },
  {
    id: 5,
    date: '2023-12-25',
    title: '第一个圣诞节',
    description: '我们交换了礼物，一起装饰了属于我们的第一棵圣诞树。',
    imageUrl: 'https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=couple%20decorating%20christmas%20tree%20together&sign=f0b0682f92d49d8eafaf5a0905e84f01'
  },
  {
    id: 6,
    date: '2024-02-14',
    title: '第一个情人节',
    description: '收到了你送的项链，上面刻着我们相识的日期，我哭了。',
    imageUrl: 'https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=valentines%20day%20gift%20surprise%20happy%20couple&sign=2a3548d646c70b1484657825e7710849'
  },
  {
    id: 7,
    date: '2024-06-01',
    title: '一周年纪念日',
    description: '一年了，时间过得好快，感觉我们才刚刚开始。',
    imageUrl: 'https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=1st%20anniversary%20celebration%20cake%20candle%20couple&sign=7d70c145ecffa7e91e6ff0a5a9da1222'
  }
];

export default function Timeline() {
  const { relationship } = useRelationship();
  const [selectedEvent, setSelectedEvent] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-gradient-to-b from-pink-50 to-white dark:from-gray-900 dark:to-gray-800 transition-colors duration-300">
      {/* 顶部导航 */}
      <header className="sticky top-0 z-30 bg-white/80 dark:bg-gray-900/80 backdrop-blur-md border-b border-pink-100 dark:border-gray-700">
        <div className="container mx-auto px-4 py-3 flex items-center justify-between">
          <Link to="/dashboard" className="text-gray-500 dark:text-gray-400 hover:text-pink-500 dark:hover:text-pink-400">
            <i className="fa-solid fa-arrow-left"></i>
          </Link>
          <h1 className="text-xl font-bold text-gray-800 dark:text-gray-200">我们的时间线</h1>
          <div className="w-6"></div> {/* 占位元素，保持标题居中 */}
        </div>
      </header>

      <main className="container mx-auto px-4 py-6">
        <div className="mb-8 text-center">
          <h2 className="text-2xl font-bold bg-gradient-to-r from-pink-500 to-rose-500 bg-clip-text text-transparent mb-2">
            {relationship?.name || '我们的故事'}
          </h2>
          <p className="text-gray-600 dark:text-gray-400">
            从 {relationship?.startDate || '2023-06-01'} 开始
          </p>
        </div>

        {/* 添加事件按钮 */}
        <div className="flex justify-end mb-8">
          <button className="bg-gradient-to-r from-pink-500 to-rose-500 hover:from-pink-600 hover:to-rose-600 text-white px-4 py-2 rounded-full shadow-md flex items-center transition-all hover:shadow-lg">
            <i className="fa-solid fa-plus mr-2"></i>
            <span>添加事件</span>
          </button>
        </div>

        {/* 时间线 */}
        <div className="relative">
          {/* 中心线 */}
          <div className="absolute left-1/2 transform -translate-x-1/2 h-full w-0.5 bg-gradient-to-b from-pink-300 via-pink-400 to-rose-400 dark:from-pink-900 dark:via-pink-800 dark:to-rose-900"></div>
          
          {/* 时间线事件 */}
          <div className="space-y-12">
            {timelineEvents.map((event, index) => (
              <div 
                key={event.id}
                className={`relative flex ${index % 2 === 0 ? 'flex-row-reverse' : ''} items-center`}
                onClick={() => setSelectedEvent(selectedEvent === event.id ? null : event.id)}
              >
                {/* 事件内容 */}
                <div className={`w-5/12 ${index % 2 === 0 ? 'ml-auto pr-8' : 'mr-auto pl-8'}`}>
                  <div className={`bg-white dark:bg-gray-800 rounded-xl p-5 shadow-sm border border-pink-100 dark:border-gray-700 transition-all cursor-pointer ${selectedEvent === event.id ? 'shadow-lg scale-105' : 'hover:shadow-md'}`}>
                    <span className="text-xs font-medium text-pink-500 dark:text-pink-400 mb-1 block">{event.date}</span>
                    <h3 className="text-xl font-bold text-gray-800 dark:text-gray-200 mb-2">{event.title}</h3>
                    <p className="text-gray-600 dark:text-gray-300 text-sm line-clamp-2">{event.description}</p>
                    
                    {selectedEvent === event.id && (
                      <div className="mt-4 rounded-lg overflow-hidden">
                        <img 
                          src={event.imageUrl} 
                          alt={event.title}
                          className="w-full h-auto rounded-lg"
                        />
                        <p className="text-gray-600 dark:text-gray-300 text-sm mt-2">{event.description}</p>
                      </div>
                    )}
                  </div>
                </div>
                
                {/* 中心圆点 */}
                <div className="absolute left-1/2 transform -translate-x-1/2 w-6 h-6 rounded-full bg-gradient-to-r from-pink-500 to-rose-500 border-4 border-white dark:border-gray-900 shadow-md z-10"></div>
              </div>
            ))}
          </div>
        </div>
      </main>

      {/* 底部导航 */}
      <footer className="fixed bottom-0 left-0 right-0 bg-white dark:bg-gray-900 border-t border-pink-100 dark:border-gray-800 z-30">
        <div className="container mx-auto">
          <div className="flex justify-around">
            <Link 
              to="/" 
              className="flex flex-col items-center py-3 px-4 text-gray-500 dark:text-gray-400 hover:text-pink-500 dark:hover:text-pink-400 transition-colors"
            >
              <i className="fa-solid fa-home text-xl mb-1"></i>
              <span className="text-xs font-medium">首页</span>
            </Link>
            <Link 
              to="/timeline" 
              className="flex flex-col items-center py-3 px-4 text-pink-500 dark:text-pink-400"
            >
              <i className="fa-solid fa-clock-rotate-left text-xl mb-1"></i>
              <span className="text-xs font-medium">时间线</span>
            </Link>
            <Link 
              to="/add" 
              className="flex flex-col items-center justify-center w-14 h-14 -mt-5 bg-gradient-to-r from-pink-500 to-rose-500 rounded-full shadow-lg text-white border-4 border-white dark:border-gray-900"
            >
              <i className="fa-solid fa-plus text-xl"></i>
            </Link>
            <Link 
              to="/memories" 
              className="flex flex-col items-center py-3 px-4 text-gray-500 dark:text-gray-400 hover:text-pink-500 dark:hover:text-pink-400 transition-colors"
            >
              <i className="fa-solid fa-camera text-xl mb-1"></i>
              <span className="text-xs font-medium">记忆</span>
            </Link>
            <Link 
              to="/profile" 
              className="flex flex-col items-center py-3 px-4 text-gray-500 dark:text-gray-400 hover:text-pink-500 dark:hover:text-pink-400 transition-colors"
            >
              <i className="fa-solid fa-user text-xl mb-1"></i>
              <span className="text-xs font-medium">我们</span>
            </Link>
          </div>
        </div>
      </footer>
    </div>
  );
}