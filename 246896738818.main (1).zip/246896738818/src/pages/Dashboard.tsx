import { useState } from 'react';
import { Link } from 'react-router-dom';
import { useTheme } from '@/hooks/useTheme';
import { cn } from '@/lib/utils';

// 模拟数据 - 重要日期
const importantDates = [
  { id: 1, title: '相识纪念日', date: '2023-05-15', daysLeft: 120 },
  { id: 2, title: '第一次约会', date: '2023-05-20', daysLeft: 125 },
  { id: 3, title: '确立关系', date: '2023-06-01', daysLeft: 137 },
];

// 模拟数据 - 最近记忆
const recentMemories = [
  { 
    id: 1, 
    title: '周末海滩之旅', 
    date: '2025-08-10', 
    imageUrl: 'https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=couple%20on%20beach%20at%20sunset%20romantic%20moment&sign=523986b74d024ccbe68910fb5f18fa97' 
  },
  { 
    id: 2, 
    title: '我们的第一顿家庭晚餐', 
    date: '2025-08-05', 
    imageUrl: 'https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=couple%20having%20dinner%20candlelight%20romantic&sign=068cebc0fcf3f542f05fd8ab5007d05b' 
  },
  { 
    id: 3, 
    title: '雨天看电影', 
    date: '2025-07-28', 
    imageUrl: 'https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=couple%20watching%20movie%20on%20couch%20rainy%20day&sign=1684434c7e09f29104fa01bcabb0b80d' 
  },
];

// 模拟数据 - 最近日记
const recentJournalEntries = [
  { id: 1, title: '我们的未来计划', date: '2025-09-10', excerpt: '今天我们聊了很多关于未来的打算，感觉我们对未来的憧憬越来越一致了...' },
  { id: 2, title: '小小的惊喜', date: '2025-09-05', excerpt: '他今天给了我一个惊喜，带我去了我们第一次约会的餐厅，太感动了...' },
];

export default function Dashboard() {
  const { theme, toggleTheme } = useTheme();
  const [relationshipDays, setRelationshipDays] = useState(486); // 模拟恋爱天数
  const [showHelp, setShowHelp] = useState(false);

  return (
    <div className="min-h-screen bg-gradient-to-b from-pink-50 to-white dark:from-gray-900 dark:to-gray-800 transition-colors duration-300">
      {/* 顶部导航 */}
      <header className="sticky top-0 z-30 bg-white/80 dark:bg-gray-900/80 backdrop-blur-md border-b border-pink-100 dark:border-gray-700">
        <div className="container mx-auto px-4 py-3 flex items-center justify-between">
          <h1 className="text-2xl font-bold bg-gradient-to-r from-pink-500 to-rose-500 bg-clip-text text-transparent">
            我们的故事
          </h1>
          <button 
            onClick={toggleTheme}
            className="p-2 rounded-full bg-pink-100 dark:bg-gray-700 text-pink-500 dark:text-pink-300 transition-colors"
            aria-label="切换主题"
          >
            {theme === 'light' ? (
              <i className="fa-solid fa-moon"></i>
            ) : (
              <i className="fa-solid fa-sun"></i>
            )}
          </button>
        </div>
      </header>

      <main className="container mx-auto px-4 py-6">
        {/* 恋爱天数卡片 */}
        <section className="mb-8">
          <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-lg overflow-hidden border border-pink-100 dark:border-gray-700 transform transition-all hover:shadow-xl">
            <div className="bg-gradient-to-r from-pink-400 to-rose-500 h-2"></div>
            <div className="p-6 text-center">
              <h2 className="text-gray-500 dark:text-gray-400 text-sm font-medium mb-2">我们已经相恋</h2>
              <div className="flex items-end justify-center gap-1 mb-2">
                <span className="text-5xl font-bold bg-gradient-to-r from-pink-500 to-rose-500 bg-clip-text text-transparent">
                  {relationshipDays}
                </span>
                <span className="text-gray-500 dark:text-gray-400 mb-1">天</span>
              </div>
              <p className="text-gray-600 dark:text-gray-300 text-sm">
                从 2023年6月1日 开始
              </p>
            </div>
          </div>
        </section>

        {/* 快速操作 */}
        <section className="mb-8 grid grid-cols-4 gap-4">
          <Link 
            to="/timeline"
            className="bg-white dark:bg-gray-800 rounded-xl p-4 text-center shadow-sm border border-pink-100 dark:border-gray-700 hover:shadow-md transition-all group"
          >
            <div className="w-12 h-12 mx-auto mb-2 rounded-full bg-pink-100 dark:bg-pink-900/30 flex items-center justify-center text-pink-500 dark:text-pink-400 group-hover:scale-110 transition-transform">
              <i className="fa-solid fa-clock-rotate-left text-xl"></i>
            </div>
            <span className="text-sm font-medium text-gray-800 dark:text-gray-200">时间线</span>
          </Link>
          
          <Link 
            to="/memories"
            className="bg-white dark:bg-gray-800 rounded-xl p-4 text-center shadow-sm border border-pink-100 dark:border-gray-700 hover:shadow-md transition-all group"
          >
            <div className="w-12 h-12 mx-auto mb-2 rounded-full bg-pink-100 dark:bg-pink-900/30 flex items-center justify-center text-pink-500 dark:text-pink-400 group-hover:scale-110 transition-transform">
              <i className="fa-solid fa-camera text-xl"></i>
            </div>
            <span className="text-sm font-medium text-gray-800 dark:text-gray-200">记忆库</span>
          </Link>
          
          <Link 
            to="/journal"
            className="bg-white dark:bg-gray-800 rounded-xl p-4 text-center shadow-sm border border-pink-100 dark:border-gray-700 hover:shadow-md transition-all group"
          >
            <div className="w-12 h-12 mx-auto mb-2 rounded-full bg-pink-100 dark:bg-pink-900/30 flex items-center justify-center text-pink-500 dark:text-pink-400 group-hover:scale-110 transition-transform">
              <i className="fa-solid fa-book text-xl"></i>
            </div>
            <span className="text-sm font-medium text-gray-800 dark:text-gray-200">日记本</span>
          </Link>
          
          <Link 
            to="/anniversaries"
            className="bg-white dark:bg-gray-800 rounded-xl p-4 text-center shadow-sm border border-pink-100 dark:border-gray-700 hover:shadow-md transition-all group"
          >
            <div className="w-12 h-12 mx-auto mb-2 rounded-full bg-pink-100 dark:bg-pink-900/30 flex items-center justify-center text-pink-500 dark:text-pink-400 group-hover:scale-110 transition-transform">
              <i className="fa-solid fa-calendar-heart text-xl"></i>
            </div>
            <span className="text-sm font-medium text-gray-800 dark:text-gray-200">纪念日</span>
          </Link>
        </section>

        {/* 纪念日倒计时 */}
        <section className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-bold text-gray-800 dark:text-gray-200">重要日期</h2>
            <Link to="/anniversaries" className="text-pink-500 dark:text-pink-400 text-sm font-medium hover:underline">
              查看全部 <i className="fa-solid fa-chevron-right ml-1 text-xs"></i>
            </Link>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {importantDates.map((date) => (
              <div key={date.id} className="bg-white dark:bg-gray-800 rounded-xl p-5 shadow-sm border border-pink-100 dark:border-gray-700 hover:shadow-md transition-all">
                <div className="flex justify-between items-start mb-3">
                  <h3 className="font-semibold text-gray-800 dark:text-gray-200">{date.title}</h3>
                  <span className="px-2 py-1 bg-pink-100 dark:bg-pink-900/30 text-pink-600 dark:text-pink-400 text-xs rounded-full">
                    {date.daysLeft} 天后
                  </span>
                </div>
                <p className="text-gray-500 dark:text-gray-400 text-sm mb-4">{date.date}</p>
                <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                  <div 
                    className="bg-gradient-to-r from-pink-400 to-rose-500 h-2 rounded-full" 
                    style={{ width: `${Math.min(100, (30 - date.daysLeft) * 3)}%` }}
                  ></div>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* 最近记忆 */}
        <section className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-bold text-gray-800 dark:text-gray-200">最近记忆</h2>
            <Link to="/memories" className="text-pink-500 dark:text-pink-400 text-sm font-medium hover:underline">
              查看全部 <i className="fa-solid fa-chevron-right ml-1 text-xs"></i>
            </Link>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {recentMemories.map((memory) => (
              <Link 
                key={memory.id} 
                to={`/memories/${memory.id}`}
                className="group relative overflow-hidden rounded-xl aspect-square shadow-sm border border-pink-100 dark:border-gray-700"
              >
                <img 
                  src={memory.imageUrl} 
                  alt={memory.title}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/30 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-4">
                  <h3 className="text-white font-semibold text-lg">{memory.title}</h3>
                  <p className="text-gray-200 text-sm">{memory.date}</p>
                </div>
              </Link>
            ))}
          </div>
        </section>

        {/* 最近日记 */}
        <section>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-bold text-gray-800 dark:text-gray-200">最近日记</h2>
            <Link to="/journal" className="text-pink-500 dark:text-pink-400 text-sm font-medium hover:underline">
              查看全部 <i className="fa-solid fa-chevron-right ml-1 text-xs"></i>
            </Link>
          </div>
          
          <div className="space-y-4">
            {recentJournalEntries.map((entry) => (
              <Link 
                key={entry.id}
                to={`/journal/${entry.id}`}
                className="bg-white dark:bg-gray-800 rounded-xl p-5 shadow-sm border border-pink-100 dark:border-gray-700 hover:shadow-md transition-all"
              >
                <div className="flex justify-between items-start mb-2">
                  <h3 className="font-semibold text-gray-800 dark:text-gray-200">{entry.title}</h3>
                  <span className="text-gray-500 dark:text-gray-400 text-sm">{entry.date}</span>
                </div>
                <p className="text-gray-600 dark:text-gray-300 text-sm line-clamp-2">{entry.excerpt}</p>
              </Link>
            ))}
          </div>
        </section>
      </main>

      {/* 底部导航 */}
      <footer className="fixed bottom-0 left-0 right-0 bg-white dark:bg-gray-900 border-t border-pink-100 dark:border-gray-800 z-30">
        <div className="container mx-auto">
          <div className="flex justify-around">
            <Link 
              to="/" 
              className="flex flex-col items-center py-3 px-4 text-pink-500 dark:text-pink-400"
            >
              <i className="fa-solid fa-home text-xl mb-1"></i>
              <span className="text-xs font-medium">首页</span>
            </Link>
            <Link 
              to="/timeline" 
              className="flex flex-col items-center py-3 px-4 text-gray-500 dark:text-gray-400 hover:text-pink-500 dark:hover:text-pink-400 transition-colors"
            >
              <i className="fa-solid fa-clock-rotate-left text-xl mb-1"></i>
              <span className="text-xs font-medium">时间线</span>
            </Link>
            <Link 
              to="/add" 
              className="flex flex-col items-center justify-center w-14 h-14 -mt-5 bg-gradient-to-r from-pink-500 to-rose-500 rounded-full shadow-lg text-white border-4 border-white dark:border-gray-900"
            >
              <i className="fa-solid fa-plus text-xl"></i>
            </Link>
            <Link 
              to="/memories" 
              className="flex flex-col items-center py-3 px-4 text-gray-500 dark:text-gray-400 hover:text-pink-500 dark:hover:text-pink-400 transition-colors"
            >
              <i className="fa-solid fa-camera text-xl mb-1"></i>
              <span className="text-xs font-medium">记忆</span>
            </Link>
            <Link 
              to="/profile" 
              className="flex flex-col items-center py-3 px-4 text-gray-500 dark:text-gray-400 hover:text-pink-500 dark:hover:text-pink-400 transition-colors"
            >
              <i className="fa-solid fa-user text-xl mb-1"></i>
              <span className="text-xs font-medium">我们</span>
           </Link>
         </div>
       </div>
     </footer>
     
     {/* 帮助模态框 */}
     {showHelp && (
       <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
         <div className="bg-white dark:bg-gray-800 rounded-2xl max-w-2xl w-full max-h-[80vh] overflow-y-auto shadow-2xl border border-pink-100 dark:border-gray-700">
           {/* 模态框头部 */}
           <div className="sticky top-0 bg-white dark:bg-gray-800 z-10 border-b border-pink-100 dark:border-gray-700 px-6 py-4 rounded-t-2xl flex justify-between items-center">
             <h3 className="text-xl font-bold text-gray-800 dark:text-gray-200 flex items-center">
               <i className="fa-solid fa-question-circle text-pink-500 mr-2"></i>
               网站使用指南
             </h3>
             <button 
               onClick={() => setShowHelp(false)}
               className="text-gray-500 dark:text-gray-400 hover:text-pink-500 dark:hover:text-pink-400 transition-colors"
             >
               <i className="fa-solid fa-times"></i>
             </button>
           </div>
           
           {/* 模态框内容 */}
           <div className="p-6 space-y-6">
             <div>
               <h4 className="text-lg font-semibold text-gray-800 dark:text-gray-200 mb-3 flex items-center">
                 <i className="fa-solid fa-compass text-pink-500 mr-2"></i>
                 基本导航
               </h4>
               <p className="text-gray-600 dark:text-gray-300 mb-4">
                 网站底部有五个主要导航按钮，分别是：首页、时间线、添加内容、记忆库和我们。点击中间的"+"按钮可以快速添加新内容。
               </p>
             </div>
             
             <div>
               <h4 className="text-lg font-semibold text-gray-800 dark:text-gray-200 mb-3 flex items-center">
                 <i className="fa-solid fa-clock-rotate-left text-pink-500 mr-2"></i>
                 时间线
               </h4>
               <p className="text-gray-600 dark:text-gray-300 mb-4">
                 时间线记录了你们恋爱过程中的重要事件。点击"添加事件"按钮可以创建新事件，包括标题、日期和描述。点击事件卡片可以查看详情。
               </p>
             </div>
             
             <div>
               <h4 className="text-lg font-semibold text-gray-800 dark:text-gray-200 mb-3 flex items-center">
                 <i className="fa-solid fa-camera text-pink-500 mr-2"></i>
                 记忆库
               </h4>
               <p className="text-gray-600 dark:text-gray-300 mb-4">
                 记忆库用于存储照片和视频。你可以创建不同相册分类管理，点击"添加照片"按钮上传新照片，点击照片可以查看大图和详情。
               </p>
             </div>
             
             <div>
               <h4 className="text-lg font-semibold text-gray-800 dark:text-gray-200 mb-3 flex items-center">
                 <i className="fa-solid fa-book text-pink-500 mr-2"></i>
                 日记本
               </h4>
               <p className="text-gray-600 dark:text-gray-300 mb-4">
                 日记本可以记录你们的日常心情和故事。点击"写日记"按钮开始记录，你可以添加标题、内容，并标记当天的心情和天气。
               </p>
             </div>
             
             <div>
               <h4 className="text-lg font-semibold text-gray-800 dark:text-gray-200 mb-3 flex items-center">
                 <i className="fa-solid fa-calendar-heart text-pink-500 mr-2"></i>
                 纪念日
               </h4>
               <p className="text-gray-600 dark:text-gray-300 mb-4">
                 纪念日功能可以帮助你记录和提醒重要日期。点击"添加纪念日"按钮，输入名称、日期和描述，系统会自动计算倒计时并在当天提醒你。
               </p>
             </div>
             
             <div>
               <h4 className="text-lg font-semibold text-gray-800 dark:text-gray-200 mb-3 flex items-center">
                 <i className="fa-solid fa-user text-pink-500 mr-2"></i>
                 我们
               </h4>
               <p className="text-gray-600 dark:text-gray-300 mb-4">
                 在"我们"页面，你可以编辑情侣信息，包括双方名称和恋爱开始日期。系统会自动计算恋爱天数、月数和年数，并显示在个人资料顶部。
               </p>
             </div>
           </div>
           
           {/* 模态框底部 */}
           <div className="sticky bottom-0 bg-white dark:bg-gray-800 z-10 border-t border-pink-100 dark:border-gray-700 px-6 py-4 rounded-b-2xl flex justify-center">
             <button 
               onClick={() => setShowHelp(false)}
               className="bg-gradient-to-r from-pink-500 to-rose-500 hover:from-pink-600 hover:to-rose-600 text-white px-6 py-2 rounded-full shadow-md transition-all hover:shadow-lg"
             >
               我知道了
             </button>
           </div>
         </div>
       </div>
     )}
   </div>
  );
}