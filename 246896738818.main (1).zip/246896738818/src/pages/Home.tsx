import { useEffect, useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import { AuthContext } from '@/contexts/authContext';

export default function Home() {
  const { isAuthenticated } = useContext(AuthContext);
  const navigate = useNavigate();
  
  useEffect(() => {
    // 重定向到仪表盘
    navigate('/dashboard');
  }, [isAuthenticated, navigate]);
  
  return null;
}