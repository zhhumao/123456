import { Routes, Route } from "react-router-dom";
import Home from "@/pages/Home";
import Dashboard from "@/pages/Dashboard";
import Timeline from "@/pages/Timeline";
import Memories from "@/pages/Memories";
import Journal from "@/pages/Journal";
import Anniversaries from "@/pages/Anniversaries";
import Profile from "@/pages/Profile";
import AddPage from "@/pages/AddPage";
import { useState } from "react";
import { AuthContext } from '@/contexts/authContext';

export default function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  const logout = () => {
    setIsAuthenticated(false);
  };

  return (
    <AuthContext.Provider
      value={{ isAuthenticated, setIsAuthenticated, logout }}
    >
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/timeline" element={<Timeline />} />
  <Route path="/memories" element={<Memories />} />
  <Route path="/memories/:id" element={<Memories />} />
        <Route path="/journal" element={<Journal />} />
        <Route path="/anniversaries" element={<Anniversaries />} />
        <Route path="/profile" element={<Profile />} />
        <Route path="/add" element={<AddPage />} />
      </Routes>
    </AuthContext.Provider>
  );
}