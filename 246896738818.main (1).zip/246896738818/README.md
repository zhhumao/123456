# 恋爱记录网站使用指南

## 所需软件

- [Node.js](https://nodejs.org/) (v14.0.0 或更高版本)
- [pnpm](https://pnpm.io/) (包管理器)
- 代码编辑器 (推荐 [VS Code](https://code.visualstudio.com/))
- 现代浏览器 (Chrome, Firefox, Safari 或 Edge)

## 技术栈

- React 18+ (前端框架)
- TypeScript (类型检查)
- Tailwind CSS (样式框架)
- React Router (路由管理)
- Framer Motion (动画效果)
- Recharts (数据可视化)

## 安装步骤

1. **克隆或下载项目代码**

2. **安装依赖**
   ```bash
   pnpm install
   ```

3. **启动开发服务器**
   ```bash
   pnpm dev
   ```

4. **在浏览器中访问**
   打开 http://localhost:3000 即可查看网站

## 项目结构

- `src/pages` - 包含网站各个页面组件
- `src/components` - 可复用的UI组件
- `src/contexts` - React上下文
- `src/hooks` - 自定义React钩子
- `src/lib` - 工具函数和辅助代码

## 主要功能

- 时间线 - 记录恋爱历程中的重要事件
- 记忆库 - 存储和管理照片回忆
- 日记本 - 记录日常心情和故事
- 纪念日 - 跟踪重要日期和倒计时

## 构建生产版本

```bash
pnpm build
```
构建后的文件将保存在 `dist` 目录中，可以部署到任何静态网站托管服务。